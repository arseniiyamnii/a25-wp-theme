# wp-theme-template  
## My WP theme for fastcreating custom themes
i used it only for personal purpose .it used starnge libraries and dotfiles, but i try to explain all things))  
in final we must get theme, with bootstrap, and many guttenberg blocks. Every block must be in own git repo(maybe)
i need custom vimrc, npmscripts, phpcs, phpcs-fixer(or something like this), js linter, js unit tests(maybe), babelrc(for gutenberg), scss compiler, npm watcher, etc.
unused functions must be commented. Also i need documentation for theme(maybe Sphinx). Well. Its many work. Lets start)))
installing tutorials:
https://camilopayan.com/posts/lint-your-php-in-vim/
https://medium.com/@mcnamee/phpcs-code-linting-for-wordpress-c340199364c6
### TO-DO
 - [ ] install linter  
 - [ ] settings linter  
 - [ ] install autoBeautifyer  
 - [ ] setting autobeautifyer  
 - [ ] 

